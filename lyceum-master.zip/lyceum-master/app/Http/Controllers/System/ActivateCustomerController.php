<?php

namespace App\Http\Controllers\System;

use Illuminate\Auth\Events\Registered;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;
use App\Mail\VerifyCustomerMail;
use App\Models\Customer\User;
use App\Models\System\Customer;
use App\Models\System\PotentialCustomer;
use Hyn\Tenancy\Environment;
use Hyn\Tenancy\Models\Hostname;
use Hyn\Tenancy\Models\Website;
use Hyn\Tenancy\Repositories\HostnameRepository;
use Hyn\Tenancy\Repositories\WebsiteRepository;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class ActivateCustomerController extends Controller
{
    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/dashboard';

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'password' => 'required|string|min:6|confirmed',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        $user = User::create([
            'name' => $this->setName($data),
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
        ]);

        // $user->guard_name = 'web';
        // $user->assignRole('admin');

        return $user;
    }

    public function setName(array $data) {
        return $data['first_name']. ' ' . $data['last_name'];
    }

    public function verifyCustomer($token)
    {
        $potentialCustomer = PotentialCustomer::where('token', $token)->first();

        $accountFound = false;

        if($potentialCustomer){

            if(!$potentialCustomer->verified) {
                $potentialCustomer->verified = 1;
                $potentialCustomer->save();
                $status = "Your email is verified.";
            } else {
                $status = "Your email is already verified.";
            }

            $accountFound = true;

            flash($status. 'Fill the information below to complete your school account setup.')->success();
        }else{

            flash("Sorry your email cannot be identified.")->error();
        }

        return view('system.completeCustomerSetup')->with([
            'customer' => $potentialCustomer,
            'accountFound' => $accountFound,
        ]);

    }

    /**
     * Handle a registration request for the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function setupCustomer(Request $request)
    {
        $this->validator($request->all())->validate();

        try {

            $potentialCustomer = PotentialCustomer::where('id', $request->customer_id)->first();

            if (!$potentialCustomer || (!$potentialCustomer->verified == 1)) {
                flash("Sorry your email cannot be identified.")->error();
                return back()->withInput()->with(['accountFound' => false]);
            }

        } catch (\Exception $exception) {
            flash("Your school cannot be setup. Please retry.")->error();
            return back()->withInput()->with(['accountFound' => true]);
        }

        $subDomain = $potentialCustomer->sub_domain;

        $baseUrl = config('app.url_base');
        $fqdn = "{$subDomain}.{$baseUrl}";

        $redirectTo = "http://{$subDomain}.{$request->getHttpHost()}";

        if (!$website = $this->createWebsite($fqdn)) {
            flash("Your school cannot be setup. Please retry.")->error();
            return back()->withInput()->with(['accountFound' => true]);
        }

        $hostname = $website->hostnames->first();

        if (!$customer = $this->createCustomer($potentialCustomer, $website)) {

            $this->deleteHostname($hostname);
            $this->deleteWebsite($website);

            flash("Your school cannot be setup. Please retry.")->error();
            return back()->withInput()->with(['accountFound' => true]);
        }

        $tenancy = app(Environment::class);
        $tenancy->tenant($website);

        try {
            event(new Registered($user = $this->create($request->all())));

            $this->guard()->login($user);

            $potentialCustomer->delete();

        } catch (\Exception $exception) {

            $customer->delete();
            $this->deleteHostname($hostname);
            $this->deleteWebsite($website);

            flash("Your school cannot be setup. Please retry.")->error();
            return back()->withInput()->with(['accountFound' => true]);
        }

        return $this->registered($request, $user)
            ?: redirect($redirectTo . '/dashboard');
    }

    public function createWebsite($fqdn): ?Website
    {
        // create website
        try {

            $website = new Website;
            app(WebsiteRepository::class)->create($website);
        } catch (\Exception $exception) {

            return null;

        }

        // create hostname and attach it to website
        try {

            $hostname = new Hostname;
            $hostname->fqdn = $fqdn;
            app(HostnameRepository::class)->attach($hostname, $website);

        } catch (\Exception $exception) {

            $this->deleteWebsite($website);

            return null;
        }

        return $website;
    }

    public function createCustomer($data, Website $website): ?Customer
    {
        try {

            $customer = new Customer;

            $customer->name = $data['name'];
            $customer->sub_domain = $data['sub_domain'];
            $customer->email = $data['email'];
            $customer->website_id = $website->id;

            $customer->save();

            return $customer;

        } catch (\Exception $exception) {
            return null;
        }
    }

    public function deleteWebsite(Website $website)
    {
        app(WebsiteRepository::class)->delete($website, true);
    }

    public function deleteHostname(Hostname $hostname)
    {
        app(HostnameRepository::class)->delete($hostname, true);
    }


    protected function guard()
    {
        return Auth::guard('customer');
    }
}
