<?php

namespace App\Http\Controllers\System;

use App\Models\System\Customer;
use App\Http\Controllers\Controller;

class CustomerController extends Controller
{
    public function customers()
    {
        $customers = Customer::with('website')->get();

        return view('system.customers')
            ->with(['customers' => $customers]);
    }
}
