<?php

namespace App\Http\Controllers\System;

use App\Models\System\Customer;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TenantDomain extends Controller
{
    public function showDomainSelectionForm()
    {
        return view('system.auth.domain');
    }

    public function verifyDomain(Request $request)
    {
        $subDomain = $request->sub_domain;

        if ($school = $this->getCustomer($subDomain)) {

            $redirectTo = "http://{$subDomain}.{$request->getHttpHost()}/login";

            flash("Next time just type {$redirectTo} in your browser's address bar");

            return redirect($redirectTo);

        }

        return back()->withErrors(['sub_domain' => 'Your sub domain not found'])->withInput();

    }

    public function getCustomer($subDomain)
    {
        return Customer::where('sub_domain', $subDomain)->first();
    }
}
