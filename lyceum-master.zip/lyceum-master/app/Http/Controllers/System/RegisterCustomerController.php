<?php

namespace App\Http\Controllers\System;

use App\Mail\VerifyCustomerMail;
use App\Models\System\Customer;
use App\Models\System\PotentialCustomer;
use App\User;
use Carbon\Carbon;
use Hyn\Tenancy\Environment;
use Hyn\Tenancy\Models\Hostname;
use Hyn\Tenancy\Models\Website;
use Hyn\Tenancy\Repositories\HostnameRepository;
use Hyn\Tenancy\Repositories\WebsiteRepository;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class RegisterCustomerController extends Controller
{
    public function showSignUpForm()
    {
        return view('system.auth.register');
    }

    protected function validator(array $data)
    {
        return Validator::make($data, [
            'school_name' => 'required|string|max:255',
            'sub_domain' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        return PotentialCustomer::create([
            'name' => $data['school_name'],
            'sub_domain' => $data['sub_domain'],
            'email' => $data['email'],
            'token' => base64_encode(str_random(64)),
            'expired_at' => Carbon::now()->addDays(2),

        ]);
    }

    public function signUp(Request $request)
    {
        $this->validator($request->all())->validate();

        $email = $request->email;
        $subDomain = $request->sub_domain;

        if ($this->customerExists($email, $subDomain)) {

            flash("A school with sub domain '{$subDomain}' and/or email address '{$email}' already exists.")
                ->error();
            return back()->withInput();
        }

        $customer = $this->create($request->all());

        Mail::to($customer->email)->send(new VerifyCustomerMail($customer));

        flash('Thank you for signing up. An email has been sent to you to activate your account.')
            ->success();
        return back();
    }

    public function customerExists($email, $subDomain): bool
    {
        $customer = Customer::where('sub_domain', $subDomain)->orWhere('email', $email)->exists();

        $potentialCustomer = PotentialCustomer::where('sub_domain', $subDomain)->orWhere('email', $email)->exists();

        return $customer || $potentialCustomer;
    }
}
