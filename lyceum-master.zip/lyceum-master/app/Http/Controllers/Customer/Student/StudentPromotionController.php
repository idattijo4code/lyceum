<?php

namespace App\Http\Controllers\Customer\Student;

use App\Customers\Models\Student\StudentPromotion;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class StudentPromotionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\StudentPromotion  $studentPromotion
     * @return \Illuminate\Http\Response
     */
    public function show(StudentPromotion $studentPromotion)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\StudentPromotion  $studentPromotion
     * @return \Illuminate\Http\Response
     */
    public function edit(StudentPromotion $studentPromotion)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\StudentPromotion  $studentPromotion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, StudentPromotion $studentPromotion)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\StudentPromotion  $studentPromotion
     * @return \Illuminate\Http\Response
     */
    public function destroy(StudentPromotion $studentPromotion)
    {
        //
    }
}
