<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\URL;

class CustomerDomain
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $subDomain = 'customer';

        $route = [
            "{$subDomain}" => $request->route()->parameter($subDomain),
        ];

        URL::defaults($route);

        // Remove these params so they aren't passed to controllers.
        $request->route()->forgetParameter($subDomain);

        return $next($request);
    }
}
