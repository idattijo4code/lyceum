<?php

namespace App\Http\Middleware;

use Closure;
use Hyn\Tenancy\Environment;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;

class EnforceSystem
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        Config::set('database.default', 'system');
        Auth::shouldUse('system');
        return $next($request);
    }
}
