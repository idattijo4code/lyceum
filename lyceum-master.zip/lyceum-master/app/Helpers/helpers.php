<?php
/*
|----------------------------------------------------------------
| This helper function is used to make dynamic inclusion
| of vue component using single blade file
|---------------------------------------------------------------
*/
if (! function_exists('vue_view')) {

    function vue_view($component, $template = 'tenant', $data = [], $status = 200, array $headers = [])
    {
        $templateData = array_merge([
            'component' => $component,
            'template' => $template
        ], $data);

        return response()->view('shared.vueTemplate', $templateData, $status, $headers);
    }

}
