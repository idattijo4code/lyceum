<?php

namespace App\Models\Customer;

use Illuminate\Database\Eloquent\Model;

class Permission extends Model
{
    //
}
