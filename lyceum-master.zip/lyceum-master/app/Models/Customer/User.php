<?php

namespace App\Models\Customer;

use Hyn\Tenancy\Traits\UsesTenantConnection;
use App\User as SharedUser;

class User extends SharedUser
{
    use UsesTenantConnection;
}
