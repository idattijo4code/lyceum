<?php

namespace App\Models\Customer\Student;

use Illuminate\Database\Eloquent\Model;

class StudentPromotion extends Model
{
    //
}
