<?php

namespace App\Models\Customer\Student;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    //
}
