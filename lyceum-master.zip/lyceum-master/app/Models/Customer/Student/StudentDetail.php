<?php

namespace App\Models\Customer\Student;

use Illuminate\Database\Eloquent\Model;

class StudentDetail extends Model
{
    //
}
