<?php

namespace App\Models\Customer\School;

use Hyn\Tenancy\Traits\UsesTenantConnection;
use Illuminate\Database\Eloquent\Model;

class SchoolClass extends Model
{
    use UsesTenantConnection;

    protected $fillable = [
        'title', 'description'
    ];
}
