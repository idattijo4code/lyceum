<?php

namespace App\Models\Customer\School;

use Hyn\Tenancy\Traits\UsesTenantConnection;
use Illuminate\Database\Eloquent\Model;

class SchoolClassSubject extends Model
{
    use UsesTenantConnection;

    protected $fillable = [

    ];
}
