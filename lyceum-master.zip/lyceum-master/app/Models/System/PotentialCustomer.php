<?php

namespace App\Models\System;

use Illuminate\Database\Eloquent\Model;

class PotentialCustomer extends Model
{
    protected $fillable = [
        'name', 'sub_domain', 'email', 'token', 'expired_at'
    ];
}
