<?php

namespace App\Models\System;

use App\User as SharedUser;
use Hyn\Tenancy\Traits\UsesSystemConnection;

class User extends SharedUser
{
    use UsesSystemConnection;
}
