<?php

namespace App\Models\System;

use Hyn\Tenancy\Models\Website;
use Hyn\Tenancy\Traits\UsesSystemConnection;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use UsesSystemConnection;

    protected $fillable = [
        'name', 'sub_domain', 'email', 'website_id'
    ];

    public function website()
    {
        return $this->belongsTo(Website::class);
    }
}
