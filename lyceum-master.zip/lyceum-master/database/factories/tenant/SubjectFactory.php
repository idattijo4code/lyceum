<?php

use Faker\Generator as Faker;

$factory->define(\App\Models\Customer\School\Subject::class, function (Faker $faker) {
    return [
        'title' => $faker->word
    ];
});
