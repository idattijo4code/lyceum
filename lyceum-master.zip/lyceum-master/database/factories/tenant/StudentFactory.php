<?php

use Faker\Generator as Faker;

$factory->define(\App\Models\Customer\Student\Student::class, function (Faker $faker) {
    return [
        //
    ];
});
