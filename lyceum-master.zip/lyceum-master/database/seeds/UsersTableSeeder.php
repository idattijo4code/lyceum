<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $users = [
            [
                'name' => 'Lyceum',
                'email' => 'lyceum@lyceum.com',
                'password' => 'lyceum'
            ]
        ];

        foreach ($users as $user) {
            if (!\App\Models\System\User::where('email', $user['email'])->first()) {

                $user['password'] = \Illuminate\Support\Facades\Hash::make($user['password']);
                \App\Models\System\User::create($user);

            }
        }
    }
}
