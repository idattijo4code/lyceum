<?php

use Illuminate\Database\Seeder;

class SchoolClassesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $classAlpha = ['A', 'B', 'C'];

        for ($class = 1; $class <= 6; $class++) {
            collect($classAlpha)->map(function ($alpha) use ($class) {
                \App\Models\Customer\School\SchoolClass::firstOrCreate([
                    'title' => "{$class}{$alpha}"
                ]);
            });
        }
    }
}
