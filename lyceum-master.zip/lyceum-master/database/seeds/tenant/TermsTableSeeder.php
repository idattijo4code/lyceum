<?php

use Illuminate\Database\Seeder;

class TermsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        collect([
            ['title' => 'First', 'number' => 1],
            ['title' => 'Second', 'number' => 2],
            ['title' => 'Third', 'number' => 3]
        ])->map(function ($term) {
            \App\Models\Customer\School\Term::firstOrCreate($term);
        });
    }
}
