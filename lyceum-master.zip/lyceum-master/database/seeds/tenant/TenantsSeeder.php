<?php

namespace Database\Seeds\Tenant;

use Illuminate\Database\Seeder;

class TenantsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            \SchoolClassesTableSeeder::class,
            \SubjectTableSeeder::class,
            \TermsTableSeeder::class,
            \TenantUsersTableSeeder::class,
            \StudentsTableSeeder::class,
        ]);
    }
}
