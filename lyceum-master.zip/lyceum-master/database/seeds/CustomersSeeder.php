<?php

use App\Models\System\Customer;
use Hyn\Tenancy\Environment;
use Hyn\Tenancy\Models\Hostname;
use Hyn\Tenancy\Models\Website;
use Hyn\Tenancy\Repositories\HostnameRepository;
use Hyn\Tenancy\Repositories\WebsiteRepository;
use Illuminate\Database\Seeder;

class CustomersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $customers = [
            [
                'name' => 'Bakari Dukku Secondary School, Bauchi',
                'sub_domain' =>'bkssb',
                'email' => 'bkssb@lyceum.com'
            ],
            [
                'name' => 'Kofar Wambai Secondary School, Bauchi',
                'sub_domain' =>'kwssb',
                'email' => 'kwssb@lyceum.com'
            ]
        ];

        foreach ($customers as $customer) {

            $website = new Website;
            $subDomain = $customer['sub_domain'];
            app(WebsiteRepository::class)->create($website);

            // associate the website with a hostname
            $hostname = new Hostname;
            $baseUrl = config('app.url_base');
            $hostname->fqdn = "{$subDomain}.{$baseUrl}";

            app(HostnameRepository::class)->attach($hostname, $website);
            // make hostname current

            $school = $this->createCustomer($customer['name'], $customer['email'], $subDomain, $website);
        }


    }

    private function createCustomer($name, $email, $subDomain, Website $website)
    {
        $customer = new Customer;

        $customer->name = $name;
        $customer->sub_domain = $subDomain;
        $customer->email = $email;
        $customer->website_id = $website->id;

        $customer->save();
    }
}
